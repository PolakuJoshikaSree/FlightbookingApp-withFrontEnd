package com.bookingservice.model;

public enum MealType {
    VEG, NON_VEG
}
