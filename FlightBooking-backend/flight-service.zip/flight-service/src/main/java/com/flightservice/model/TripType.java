package com.flightservice.model;

public enum TripType {
    ONE_WAY, ROUND_TRIP
}
